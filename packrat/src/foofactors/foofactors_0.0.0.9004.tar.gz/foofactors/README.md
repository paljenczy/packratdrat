
<!-- README.md is generated from README.Rmd. Please edit that file -->
[![Build Status](https://travis-ci.org/paljenczy/foofactors.svg?branch=master)](https://travis-ci.org/paljenczy/foofactors)
